import { getTodaysWeather, getTomorrowsWeather } from "./js/api";

getTodaysWeather();
getTomorrowsWeather();
